V = 1200; Z1= 60; Z2 = 6 + j*12; Z3 = 30 - j*30;
I1 = V/Z1; I2 = V/Z2; I3 = V/Z3;
S1= V*conj(I1), S2= V*conj(I2), S3= V*conj(I3)
S = S1 + S2 + S3
Sp=rec2pol(S)   % Expressed in polar form