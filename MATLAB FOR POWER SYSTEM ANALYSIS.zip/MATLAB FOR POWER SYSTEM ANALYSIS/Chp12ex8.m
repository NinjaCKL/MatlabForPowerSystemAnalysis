disp('Open sim12ex8.mdl in SIMULINK WINDOW and click on simulation')
