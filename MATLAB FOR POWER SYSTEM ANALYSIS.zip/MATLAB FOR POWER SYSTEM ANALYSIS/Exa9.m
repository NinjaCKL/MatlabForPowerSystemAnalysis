A = [0  1  -1; -6  -11  6; -6  -11  5];
p = poly(A)
r = roots(p)
