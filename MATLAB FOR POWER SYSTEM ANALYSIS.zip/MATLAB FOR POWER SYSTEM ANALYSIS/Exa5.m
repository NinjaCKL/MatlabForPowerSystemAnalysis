i = sqrt(-1);
Zc = 200 + 300*i;
g = 0.02 + 1.5*i;
v = Zc*cosh(g) + 1/Zc * sinh(g)
