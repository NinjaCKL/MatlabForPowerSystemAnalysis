disp('Open sim12ex5.mdl in SIMULINK WINDOW and click on simulation')
