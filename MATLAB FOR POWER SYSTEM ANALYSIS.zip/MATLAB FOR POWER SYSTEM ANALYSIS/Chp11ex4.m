% (a) Initial real power P0 = 0.60
P0 = 0.6; E = 1.35; V = 1.0; X = 0.65;
eacpower(P0, E, V, X)
h=figure;
% (b) Zero initial power
P0 = 0;
eacpower(P0, E, V, X)
