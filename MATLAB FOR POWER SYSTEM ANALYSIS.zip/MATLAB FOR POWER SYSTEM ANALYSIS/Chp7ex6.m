cost = [500   5.3    0.004
        400   5.5    0.006
        200   5.8    0.009];
mwlimits=[200  450
         150  350
         100  225];
Pdt = 975;
dispatch
gencost
