num = [ 2  0  9  1];
den = [ 1  1  4  4];
[r,p,k] = residue(num, den)
