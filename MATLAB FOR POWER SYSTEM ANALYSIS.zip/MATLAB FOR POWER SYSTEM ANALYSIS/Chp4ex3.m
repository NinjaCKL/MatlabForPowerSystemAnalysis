GMRL=sqrt(18*0.3924)/12;
GMRC=sqrt(18*0.4885)/12;
GMD=(35*35*70)^(1/3);
L=0.2*log(GMD/GMRL)
C=0.0556/log(GMD/GMRC)
