disp('Open sim12ex9.mdl in SIMULINK WINDOW and click on simulation')
