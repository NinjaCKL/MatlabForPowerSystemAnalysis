R = 18; X = 60;
P = 150*0.8/3;  Q = 150*0.6/3;
V1d = 230/sqrt(3); V2d = 230/sqrt(3);
tS = sqrt((V2d/V1d)/(1 - (R*P + X*Q)/(V1d*V2d)))
tR = 1/tS
