i = sqrt(-1);
r = [-1  -2  -3+4*i  -3-4*i];
p = poly(r)
