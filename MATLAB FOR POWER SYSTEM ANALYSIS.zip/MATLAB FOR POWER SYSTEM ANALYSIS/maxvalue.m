function maxvalue(x)
i=1;
x=[];
if x(i)<x(i+1)
    max=x(i+1);
else
    max=x(i);
end
disp(max)
end
